package com.example.bloss;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {

}

