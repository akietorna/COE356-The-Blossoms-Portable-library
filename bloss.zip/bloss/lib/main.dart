import 'screens/chooseProgram.dart';
import 'package:flutter/material.dart';
import 'screens/login.dart';
import "screens/signUp.dart";
import "screens/forgotPassword.dart";
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';

Future<int> _loadLog() async {
  final prefs = await SharedPreferences.getInstance();
  return (prefs.getInt('logged_in') ?? 0);
}


void _incrementLog() async {
  final prefs = await SharedPreferences.getInstance();
  prefs.setInt('logged_in', 1);
}

Future<String> _decideMainPage() async{
  if (await _loadLog() != null) {
    if (await _loadLog()==1) {
      return '/login/landingPage/chooseProgram';
      // return RegistrationPage(prefs: prefs);
    } else {
      return '/';
    }
  } else {
    return '/';
  }
}

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIOverlays(
      [SystemUiOverlay.bottom, SystemUiOverlay.top]);
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  var logged_in = (prefs.getInt('logged_in') ?? 0);
  runApp(MyApp(logged_in));
}

class MyApp extends StatefulWidget {
  late int firstPage;
  MyApp(this.firstPage);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {



  @override
  void initState(){
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {


    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
          brightness: Brightness.dark,
          primarySwatch: Colors.orange,
          textSelectionColor: Colors.orangeAccent,
          fontFamily: 'Patrick-Hand'



      ),

//this.widget.firstPage==0?'/':'/login/landingPage/chooseProgram'
      initialRoute: this.widget.firstPage==0?'/':'/login/landingPage/chooseProgram',
      routes: {
        "/": (context) => LoginPageState(),
        "/signup": (context) => SignupPageState(),
        "/forgotPassword": (context) => ForgotPasswordState(),
        "/login/landingPage": (context) =>
            chooseProgram(),
        "/login/landingPage/chooseProgram" :(context)=> chooseProgram(),
      },
      title: "Slydehub",
    );


    //   FutureBuilder(
    //   future: Init.instance.initialize(),
    //   builder: (context, AsyncSnapshot snapshot) {
    //     // Show splash screen while waiting for app resources to load:
    //     if (snapshot.connectionState == ConnectionState.waiting) {
    //       return MaterialApp(home: Splash());
    //     } else {
    //       // Loading is done, return the app:
    //       return
    //     }
    //   },
    // );
  }
}

class Splash extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // bool lightMode =
    //     MediaQuery.of(context).platformBrightness == Brightness.light;
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
    decoration: BoxDecoration(
    image: DecorationImage(
    image: AssetImage('assets/splash.png'),
    fit: BoxFit.cover)
    )
    )
    );
  }
}

class Init {
  Init._();
  static final instance = Init._();

  Future initialize() async {
    // This is where you can initialize the resources needed by your app while
    // the splash screen is displayed.  Remove the following example because
    // delaying the user experience is a bad design practice!
    await Future.delayed(const Duration(seconds: 3));
  }
}
