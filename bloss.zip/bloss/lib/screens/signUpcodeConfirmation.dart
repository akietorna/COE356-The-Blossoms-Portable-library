import "package:flutter/material.dart";
import 'logo.dart';
import "backgroundoverlay.dart";
import 'package:dio/dio.dart';

class SignUpCodeConfirmationState extends StatefulWidget {

  late String email;
  SignUpCodeConfirmationState(this.email);

  @override
  State<StatefulWidget> createState() {
    return SignUpCodeConfirmation(this.email);
  }
}

class SignUpCodeConfirmation extends State<SignUpCodeConfirmationState> {
  late String email;

  SignUpCodeConfirmation(this.email);

  final dio = Dio();

  TextEditingController _confirmationCode = TextEditingController();
  Widget codeConfirmationIcon = Icon(Icons.coronavirus);


  Future<String> confirmCode(String code) async{
    final api_0 = 'http://slydhub.pythonanywhere.com/sign_up_confirm_code/';
    try{
      final response_0 = await dio.request(
        api_0,
        data: {'confirm_code':code
        },
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'POST'),
      );
      print(response_0.data);
      if (response_0.data['status']=="You have successfully signed up"){
        return 'forward';
      }else{
        return 'error';
      }
    }
    catch(err){
      print(err);
      return 'error';
    }
  }

  Future<String> sendCode(String email) async{
    final api_0 = 'http://slydhub.pythonanywhere.com/confirm_email/';
    try{
      final response_0 = await dio.request(
        api_0,
        data: {'email':email
        },
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'POST'),
      );
      print(response_0.data);
      if (response_0.data['status']=='mail sent'){
        return 'forward';
      }else{
        return 'error';
      }
    }
    catch(err){
      print(err);
      return 'error';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body: ListView(children: [
          SizedBox(

            height: 40.0
          ),
          Container(
            alignment: Alignment.center,
            child: Text('Confirm Code',
            style: TextStyle(
              fontSize: 30.0,
              color: Colors.orangeAccent
            ))
          ),

          SizedBox(
            height: 10.0
          ),

          LogoImage("./assets/images/code.png"),

          SizedBox(
              height: 25.0
          ),

          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.all(15),
            child: TextFormField(
              validator: (value) =>
                  value!.length == 8 ? null : "Enter sent code",
              controller: _confirmationCode,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderSide: BorderSide(

                      ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                prefixIcon: codeConfirmationIcon,
                labelText: "Confirm code",
                hintText: "Enter the confirmation code",
                // hintStyle: TextStyle(color: Colors.indigoAccent),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                child: Text("Submit"),
                onPressed: () async{
                  if(await confirmCode(this._confirmationCode.text)=='forward'){
                    Navigator.pushNamed(
                        context, "/");
                  }else{
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          backgroundColor: Colors.black,
                          content: Text('Error, code incorrect',
                              style: TextStyle(
                                  color: Colors.orangeAccent
                              ))),
                    );
                  }
                },
              ),
              Container(
                width: 100,
                margin: EdgeInsets.fromLTRB(50, 0, 0, 0),
                child: GestureDetector(
                  child: Text("Resend code"),
                  onTap: () async{
                    if(await sendCode(this.email)=='forward'){
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            backgroundColor: Colors.black,
                            content: Text('Code sent',
                            style: TextStyle(
                                color: Colors.orangeAccent
                            ))),
                      );
                    }else{
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Code could not be sent')),
                      );
                    }
                  },
                ),
              )
            ],
          )
        ]));
  }
}
