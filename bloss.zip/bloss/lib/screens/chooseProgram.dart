import 'package:flutter/material.dart';
import 'availablePrograms.dart';
import 'year_selection.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'toTitle.dart';

class chooseProgram extends StatefulWidget {

  @override
  _chooseProgramState createState() => _chooseProgramState();
}

class _chooseProgramState extends State<chooseProgram> {
  var _foundPrograms = list_of_Programs;
  var _searchedPrograms = [];

  @override
  initState() {
    // at the beginning, all users are shown
    //_foundPrograms = list_of_Programs;
    super.initState();
  }

  Future<List> _fetchData() async {
    final API_URL = 'http://ewinlab.pythonanywhere.com/programs';

    final response = await http.get(Uri.parse(API_URL));
    final data = json.decode(response.body);

    _searchedPrograms = data["programs"];
    return data["programs"];
  }

  String aboutProgram(name){
    // for(int i = 0; i<_searchedPrograms.length; i++){
    //   //print(_searchedPrograms[i]["name"]);
    //   if(_searchedPrograms[i]['name']==name){
    //     print(_searchedPrograms[i]["about"]);
    //     return _searchedPrograms[i]["about"];
    //   }else{
    //     print(_searchedPrograms[i]["about"]);
    //     return '';
    //   }
    // }

    final result = _searchedPrograms.where((element) => element["name"]==name).first;
    return result['about'];
  }

  // This function is called whenever the text field changes
  void _runFilter(String enteredKeyword) {
    var response = [];
    if (enteredKeyword.isEmpty) {
      // if the search field is empty or only contains white-space, we'll display all users
      response = list_of_Programs;
    } else {
      // we use the toLowerCase() method to make it case-insensitive
      response = list_of_Programs
          .where((program) => program
              .toString()
              .toLowerCase()
              .contains(enteredKeyword.toLowerCase()))
          .toList();
    }

    // Refresh the UI
    setState(() {
      _foundPrograms = response;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Container(
              child: Text('Choose Your Programme',
                  style: TextStyle(
                      color: Colors.orangeAccent,
                    fontSize: 20.0
                  )),),
            // SizedBox(
            //   height: 10,
            // ),
            TextField(
              onChanged: (value) => _runFilter(value),
              decoration: InputDecoration(
                labelText: 'Search',
              //   labelStyle: TextStyle(
              //     color: Colors.orangeAccent
              // ),
                suffixIcon: Icon(
                  Icons.search,
                  // color: Colors.orange.withOpacity(0.8),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            FutureBuilder(
                future: _fetchData(),
                builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                snapshot.hasData?
                Expanded(
                  child: _searchedPrograms.length > 0
                      ? ListView.builder(
                    itemCount: _foundPrograms.length,
                    itemBuilder: (context, index) => Card(
                      key: ValueKey(index),
                      elevation: 4,
                      margin: EdgeInsets.symmetric(vertical: 10),
                      child: ListTile(
                          onTap: () {

                            print('${_foundPrograms[index]} was tapped');

                            Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context)=>
                                    yearSelection(_foundPrograms[index])
                                )
                            );
                          },
                          leading: CircleAvatar(
                              backgroundImage: ExactAssetImage('assets/images/${_foundPrograms[index].toString().toLowerCase()}.png'),
                              backgroundColor: Colors.orangeAccent),
                          title: Text(toTitle('${_foundPrograms[index]} engineering'),
                              style: TextStyle(
                                  color: Colors.orange
                              )),
                          // subtitle: Text('${aboutProgram(_foundPrograms[index].toString().toLowerCase())}',
                          //     style: TextStyle(
                          //         color: Colors.black
                          //     ))
                      ),
                    ),
                  )
                      : Text(
                    'No results found',
                    style: TextStyle(fontSize: 24),
                  ),
                ):
            CircularProgressIndicator()
            ),
          ],
        ),
      ),
    );
  }
}

//Color.fromRGBO(200, 100, 255, 0.25)


// Expanded(
// child: _foundPrograms.length > 0
// ? ListView.builder(
// itemCount: _foundPrograms.length,
// itemBuilder: (context, index) => Card(
// key: ValueKey(index),
// color: Colors.orange.withOpacity(0.8),
// elevation: 4,
// margin: EdgeInsets.symmetric(vertical: 10),
// child: ListTile(
// onTap: () {
//
// Navigator.push(
// context,
// MaterialPageRoute(builder: (context)=>
// yearSelection(_foundPrograms[index])
// )
// );
//
// print('${_foundPrograms[index]} was tapped');
// },
// leading: Image.asset('assets/images/tired.jpg'),
// title: Text(_foundPrograms[index]),
// subtitle: FutureBuilder(
// future: _fetchData(_foundPrograms[index].toString()),
// builder: (BuildContext ctx, AsyncSnapshot<String> snapshot)=>
// snapshot.hasData?
// Text('ok'):
// Text('not ok'),
// )
// ),
// ),
// )
// : Text(
// 'No results found',
// style: TextStyle(fontSize: 24),
// ),
// )