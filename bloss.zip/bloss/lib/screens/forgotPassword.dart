import "package:flutter/material.dart";
import "logo.dart";
import 'package:dio/dio.dart';
import 'codeConfirmation.dart';

// import "package:software_engineering_project/screens/textfield.dart";


class ForgotPasswordState extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ForgotPassword();
  }
}

class ForgotPassword extends State<ForgotPasswordState> {
  late var _validationMessage;

  Future<String> checkEmailAndPassValidity(String email) async{
    final api = 'http://slydhub.pythonanywhere.com/forget_password/';
    var dio = Dio();
    print('$email');

    if(email.contains('@') && email.contains('.')){
      if(email.indexOf('.')>email.indexOf('@')){
        print('format ok');
        try{
          final response = await dio.request(
          api,
          data: {'email':email},
          options: Options(
              followRedirects: false,
              validateStatus: (status) { return status! < 500; },

              method:'POST'),
        );
        print(response.data);
        if (response.data['status']=='email sent'){
          return 'forward';
        }else{
          return 'error';
        }
      }
    catch(err){
    print(err);
    return 'error';
    }
        }else{
          setState(() {_validationMessage =  'Incorrect email format';});
          return 'Incorrect email format';
        }
      }
      else{
        setState(() {_validationMessage =  'Incorrect email format';});
        return 'Incorrect email format';
      }
    }


  TextEditingController _email = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _validationMessage = '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   title: Text("Forgot password"),
        //   centerTitle: true,
        //  // backgroundColor: appBarColor,
        // ),
        body: ListView(
          children: [
            SizedBox(
              height: 40.0,
            ),
            Container(
              child: Text('Forgot Password',
                style: TextStyle(
                    fontSize: 30.0,
                    color: Colors.orangeAccent
                ),),
              alignment: Alignment.center,
            ),
            LogoImage("./assets/images/forgotpassword.png"),
            SizedBox(
              height: 30.0,
            ),
            Container(
                padding:EdgeInsets.all(15),
                child:TextFormField(
                    //validator: (value) =>
                    //value!.contains("@") ? null : "Enter a valid email",
                    //autofocus: true,
                    controller: _email,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      prefixIcon: Icon(Icons.email),
                      labelText: "E-mail",
                      hintText: "Enter your e-mail",
                      // hintStyle: TextStyle(color: hintColor)
                    )
                )
            ),

            // Container(
            //   child: Text('$_validationMessage'),
            //   alignment: Alignment.center,
            // ),
            // TextFieldState(_email, "E-mail", "Enter your e-mail", emailIcon),
            Container(
                padding:EdgeInsets.only(top:15),
                child:Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      child: Text("Submit"),
                      onPressed: () async{
                        if(await checkEmailAndPassValidity(_email.text.toString())=='forward'){
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => CodeConfirmationState(_email.text.toString())),
                          );
                        }else{
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                  backgroundColor: Colors.black,
                                  content: Text('$_validationMessage',
                                      style: TextStyle(
                                          color: Colors.orangeAccent
                                      ))));
                        }
                      },
                    ),
                  ],
                )
            )

           // BackgroundOverlayState("./assets/images/forgotpassword.jpg"),

          ],
        ));
  }
}
