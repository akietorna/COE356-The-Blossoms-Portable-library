import 'package:flutter/material.dart';
import 'availablePrograms.dart';
import 'courses.dart';
import 'toTitle.dart';

class yearSelection extends StatefulWidget {
  late String name_of_program;
  yearSelection(this.name_of_program);

  @override
  _yearSelectionState createState() => _yearSelectionState(name_of_program);
}

class _yearSelectionState extends State<yearSelection> {

  late String name;
  //String name_of_program = 'computer';
  _yearSelectionState(this.name);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: landscape_listTiles(this.name)
        )
    );
  }
}

class portrait_grid extends StatelessWidget {
  late String name_of_program;

  portrait_grid(this.name_of_program);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [

        SizedBox(
            height: MediaQuery.of(context).size.height*0.15
        ),
        Container(
          child: ListTile(
            title: Text('${this.name_of_program.toUpperCase()}'),
            subtitle: Text('select your year'),
          ),
        ),
        Expanded(
            child: GridView.builder(
                itemCount: 4,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 5.0,
                    mainAxisSpacing: 10.0
                ),
                itemBuilder: (BuildContext context, int index){
                  return Card(
                    color: Colors.orange,
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context)=>
                                Courses(this.name_of_program, index+1)
                            )
                        );

                        print('portrait year ${index + 1} pressed');
                      },
                      child: Image.asset('assets/images/year${index + 1}.png',
                      fit: BoxFit.fill,
                      height: double.infinity,
                      width: double.infinity,),
                    ),
                  );
                })
        )
      ],
    );
  }
}

class landscape_listTiles extends StatelessWidget {
  //String name_of_program = 'computer';
  late String name_of_program;

  landscape_listTiles(this.name_of_program);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 70.0,
        ),
        Container(
          child: ListTile(
            title: Text(toTitle('${this.name_of_program} Engineering'),
                style: TextStyle(
                    color: Colors.orangeAccent
                )),
            subtitle: Text(toTitle('select your year'),
            style: TextStyle(
              color: Colors.orangeAccent
            ),),
          ),
        ),
        Expanded(
          child: ListView.builder(
              itemCount: 4,
              itemBuilder: (BuildContext context, int index){
                return Card(
                  margin: EdgeInsets.all(12.0),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.black12
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Image.asset('assets/images/years${index + 1}.png',
                          height: double.infinity,
                          width: double.infinity,
                        ),
                        backgroundColor: Colors.orangeAccent,
                      ),
                      onTap: (){
                        
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context)=>
                          Courses(this.name_of_program.toLowerCase(), index+1)
                          )
                        );
                        
                        print('landScape year ${index +1} pressed');
                      },
                      title: Text('Year ${index + 1}',
                          style: TextStyle(
                              color: Colors.orangeAccent
                          )),
                    ),
                  ),
                );
              }),
        )
      ],
    );
  }
}





