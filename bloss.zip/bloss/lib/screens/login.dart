import "package:flutter/material.dart";
import "backgroundoverlay.dart";
import 'httpForLoginAndSignup.dart';
import 'logo.dart';
import "package:http/http.dart" as http;
import 'dart:convert';
import 'dart:async';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

// import 'package:software_engineering_project/screens/textfield.dart';
// import 'package:software_engineering_project/screens/passwordTextField.dart';

Widget enterCredentials = Center(child:Container(
    padding: EdgeInsets.only(top:15.0,bottom:15),
    child:Text("Enter your credential...")));

Widget emailIcon = Icon(Icons.email);

class LoginPageState extends StatefulWidget {


  @override
  State<StatefulWidget> createState() {
    return LoginPage();
  }
}

class LoginPage extends State<LoginPageState> {

  late int logged_in;

  void _loadLog() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      logged_in = (prefs.getInt('logged_in') ?? 0);
    });
  }

  // void _incrementLog() async {
  //   final prefs = await SharedPreferences.getInstance();
  //     prefs.setInt('logged_in', 1);
  // }


  double paddingValue= 15.0;

  bool _obscurity = true;

  String _validationMessage = '';

  Widget passwordSufixIcon() {
    if (_obscurity == true) {
      return Icon(Icons.visibility_off);
    } else {
      return Icon(Icons.visibility);
    }
  }

  void _togglePasswordView() {
    setState(() {
      _obscurity = !_obscurity;
    });
  }

  TextEditingController _userEmail = TextEditingController();
  TextEditingController _password = TextEditingController();

  final LoginFormKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    super.setState(fn);
  }

  Future<String> checkEmailAndPassValidity(String email, String pass) async{
    print('$email $pass');
    if(email.contains('@') && email.contains('.')){
      if(email.indexOf('.')>email.indexOf('@')){
        var apires = await apiCalltoLogin(email, pass);
        print('format ok');
        print('in here ${apires}');
        if(apires =='Log in succesfully'){
          setState(() {_validationMessage =  '';});
          return 'logged in';
        }else{
          setState(() {_validationMessage =  'Email or password incorrect';});
          return 'Email or password incorrect';
        }
      }
      else{
        setState(() {_validationMessage =  'Incorrect email';});
        return 'Incorrect email';
      }
    }else{
      setState(() {_validationMessage =  'Incorrect email';});
      return 'Incorrect email';
    }
  }

  Future<String> apiCalltoLogin(String email, String pass) async{
    final api = 'http://slydhub.pythonanywhere.com/';
    var dio = Dio();
    // try{
    //    response = await http.post(
    //      Uri.parse('http://slydhub.pythonanywhere.com/'),
    //      headers: <String, String>{
    //        'Content-Type': 'application/json; charset=UTF-8',
    //      },
    //      body: {
    //        "email": email,
    //        "password": pass
    //      },
    //    );

       try{
         // final response = await http.post(Uri.parse(api),
         //     body: json.encode({
         //       "email": email,
         //       "password":pass
         //     }));
         // // final data = json.decode(response.body) as Map;
         // // print(data);
         // // return data["status"];
         // print(response.body);
         final response = await dio.request(
           api,
           data: {'email':email,'password':pass},
           options: Options(method:'POST'),
         );
         print(response.data["status"]);
         return response.data["status"].toString();
       }
       catch(err){
         print(err);
         return 'error';
       }
    //  }
    //  catch(e){
    //    print(e);
    //    return 'error';
    //  }
    //    final results = json.decode(response.body);
    // print(results['status']);
    //    return results['status'];
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: ListView(children: [
          Container(
            margin: EdgeInsets.only(top: 30),
            child: Column(
              children: [
                Text(
                  "Login",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 30.0,
                      color: Colors.orangeAccent
                  ),
                ),
                LogoImage("./assets/images/logo2.png"),
                SizedBox(
                  height: 20.0,
                ),
                Container(
                  child: Form(
                    key: LoginFormKey,
                    child: Column(children: [

                      //Login user email entry point

                      Container(

                        padding: EdgeInsets.all(paddingValue),
                        child:TextFormField(
                            validator: (_userEmail) {
                              if(_userEmail!.contains("@")){
                                return '';
                              }
                              else{
                                return("Enter a correct email");
                              }
                            },
                            controller: _userEmail,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.white),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              prefixIcon: Icon(Icons.email),
                              labelText: "E-mail",
                              hintText: "Enter your e-mail",
                              // hintStyle: TextStyle(color: hintColor)
                            ))
                      )
                      ,
                      // user password entry point

                      Container(

                          padding: EdgeInsets.all( paddingValue ),
                        child:TextFormField(
                            validator: (_password) {
                              if(_password!.length <8){
                                return ("Enter a new password your password is too short");
                              }
                              else{
                                return null;
                              }
                            },
                            controller: _password,
                            obscureText: _obscurity,
                            decoration: InputDecoration(
                              prefixIcon: Icon(Icons.lock),
                              suffix: InkWell(
                                  onTap: _togglePasswordView,
                                  child: passwordSufixIcon()),
                              border: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.red,
                                ),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              labelText: "Password",
                              hintText: "Enter your password",
                            ))
                      ),

                      // Container(child: Text(_validationMessage),),

                          // call to actions

                      Container(
                        margin: EdgeInsets.only(top: 20),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.pushNamed(
                                              context, "/forgotPassword");
                                        },
                                          child: Container(
                                              alignment: Alignment.center,
                                              width: 110,
                                              height: 30,
                                              color: Colors.transparent,
                                              child: Text("forgot password")),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(left: 95),
                                      alignment: Alignment.centerRight,

                                      child: GestureDetector(
                                          onTap: (){
                                            Navigator.pushNamed(context,"/signup");
                                          },

                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              /* Icon(Icons.person_add),*/
                                              Container(
                                                  alignment: Alignment.center,
                                                  width: 70,
                                                  height: 30,
                                                  color: Colors.transparent,
                                                  child: Text("Sign-up")),
                                            ],
                                          )),
                                    ),
                                  ]),
                              Container(
                                alignment: Alignment.bottomCenter,
                                margin: EdgeInsets.only(top: 30),
                                child: ElevatedButton(
                                    child: Text("Log in"),
                                     onPressed: ()async{
                                      if(await checkEmailAndPassValidity(_userEmail.text.toString(), _password.text.toString())=='logged in'){
                                        final prefs = await SharedPreferences.getInstance();
                                        prefs.setInt('logged_in', 1);
                                        Navigator.pushNamed(context,"/login/landingPage");
                                      }else{
                                        ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                                backgroundColor: Colors.black,
                                                content: Text('$_validationMessage',
                                                    style: TextStyle(
                                                        color: Colors.orangeAccent
                                                    ))));
                                      }
                                     }),
                              )
                            ]),
                      )
                    ]),
                  ),
                ),

                // TextFieldState(
                //     _userEmail, "E-mail", "Enter your e-mail", emailIcon),
                // PasswordFieldState(_password, "Password",
                //     "Enter your password", passwordIcon),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
