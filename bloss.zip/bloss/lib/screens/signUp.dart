import 'package:flutter/material.dart';
import 'logo.dart';
import "backgroundoverlay.dart";
import 'login.dart';
import "httpForLoginAndSignup.dart";
// import 'package:software_engineering_project/screens/textfield.dart';
import 'package:dio/dio.dart';
import 'signUpcodeConfirmation.dart';

Widget nameIcon = Icon(Icons.person);

class SignupPageState extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SignupPage();
  }
}

class SignupPage extends State<SignupPageState> {

  final dio = Dio();

  String emailValidator (String email){
    if(email.contains('@') && email.contains('.')){
      if(email.lastIndexOf('.')>email.indexOf('@')){
        return '';
      }else{
        return 'Incorrect email format';
      }
    }
    else{
      return 'Incorrect email format';
    }
    return 'Incorrect email format';
  }

  void _onChanged(int key, String val){
    switch(key){
      case 0: (){
        if (val.isEmpty){
          setState(() {
            message_0 = 'Please enter your first name';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = '';
            message_5 = '';
          });
        }else{
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = '';
            message_5 = '';
          });
        }
      };
      break;


      case 1:(){
        if (val.isEmpty){
          setState(() {
            message_0 = '';
            message_1 = 'Please enter your last name';
            message_2 = '';
            message_3 = '';
            message_4 = '';
            message_5 = '';
          });
        }else{
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = '';
            message_5 = '';
          });
        }
      };
      break;

      case 2:(){
        if (val.isEmpty){
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = 'Please enter your username';
            message_3 = '';
            message_4 = '';
            message_5 = '';
          });
        }else{
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = '';
            message_5 = '';
          });
        }
      };
      break;

      case 3:(){
        if (val.isEmpty){
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = 'Please enter your email';
            message_4 = '';
            message_5 = '';
          });
        }else{
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = emailValidator(val);
            message_4 = '';
            message_5 = '';
          });
        }
      };
      break;

      case 4:(){
        if (val.isEmpty){
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = 'Please enter your password';
            message_5 = '';
          });
        }else{
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = val.length<8?'Password should at least 8 characters':'';
            message_5 = '';
          });
        }
      };
      break;

      case 5:(){
        if (val.isEmpty){
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = '';
            message_5 = 'Please confirm your password';
          });
        }else{
          setState(() {
            message_0 = '';
            message_1 = '';
            message_2 = '';
            message_3 = '';
            message_4 = '';
            message_5 = val==_confirmPassword.text?'':'Passwords do not match';
          });
        }
      };
      break;

      default:(){
        setState(() {
          message_0 = '';
          message_1 = '';
          message_2 = '';
          message_3 = '';
          message_4 = '';
          message_5 = '';
        });
      };
    }
  }

  String message_0 = '';
  String message_1 = '';
  String message_2 = '';
  String message_3 = '';
  String message_4 = '';
  String message_5 = '';

  Future<String> signUp(String email,String fname,String lname,String uname,String pass,String cpass) async{
    final api = 'http://slydhub.pythonanywhere.com/sign_up/';
    try{
      final response = await dio.request(
        api,
        data: {'email':email,
        'firstname':fname,
        'lastname':lname,
        'username':uname,
        'password':pass,
        'confirm_password':cpass},
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'POST'),
      );
      print(response.data);
      if (response.data['status']=='progress'){
        return 'forward';
      }else{
        return 'error';
      }
    }
    catch(err){
      print(err);
      return 'error';
    }
  }

  Future<String> sendCode(String email) async{
    final api_0 = 'http://slydhub.pythonanywhere.com/confirm_email/';
    try{
      final response_0 = await dio.request(
        api_0,
        data: {'email':email
        },
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'POST'),
      );
      print(response_0.data);
      if (response_0.data['status']=='mail sent'){
        return 'forward';
      }else{
        return 'error';
      }
    }
    catch(err){
      print(err);
      return 'error';
    }
  }

  bool _obscurity = true;

  Widget passwordSufixIcon() {
    if (_obscurity == true) {
      return Icon(Icons.visibility_off);
    } else {
      return Icon(Icons.visibility);
    }
  }

  void _togglePasswordView() {
    setState(() {
      _obscurity = !_obscurity;
    });
  }

  final signUpKey = GlobalKey<FormState>();

  TextEditingController _firstName = TextEditingController();
  TextEditingController _lastName = TextEditingController();
  TextEditingController _userName = TextEditingController();
  TextEditingController _userEmail = TextEditingController();
  TextEditingController _password = TextEditingController();
  TextEditingController _confirmPassword = TextEditingController();

  double paddingValue = 15.0;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          // appBar: AppBar(
          //   title: Text("Sign-up"),
          //   centerTitle: true,
          //   //backgroundColor: appBarColor,
          // ),
          body: ListView(
            children: [
              LogoImage("./assets/images/signup.png"),
              SizedBox(
                height: 30.0,
              ),
              Container(
                  child: Form(
                      key: signUpKey,
                      child: Column(children: [
                        //First name
                        Container(

                          padding: EdgeInsets.all(paddingValue),

                          child:TextFormField(
                              // validator: (value) => value!.isEmpty
                              //     ? "Please enter your first name"
                              //     : '',
                              // autofocus: true,
                              controller: _firstName,
                              onChanged: (val){
                                _onChanged(0, val);
                              },
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                prefixIcon: Icon(Icons.person),
                                labelText: "First Name",
                                hintText: "Enter your first name",
                                // hintStyle: TextStyle(color: hintColor)
                              ))
                        ),
                        Container(
                          child: Text(message_0),
                        ),

                        //Last name
                        Container(

                            padding: EdgeInsets.all( paddingValue),
                          child:TextFormField(
                              // validator: (value) => value!.isEmpty
                              //     ? "Please enter your last name"
                              //     : '',
                            onChanged: (val){
                              _onChanged(1, val);
                            },
                              controller: _lastName,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                prefixIcon: Icon(Icons.person),
                                labelText: "Last Name",
                                hintText: "Enter your first name",
                                // hintStyle: TextStyle(color: hintColor)
                              ))
                        )
                        ,Container(
                          child: Text(message_1),
                        )
                        ,
                        Container(

                            padding: EdgeInsets.all( paddingValue),
                          child:TextFormField(
                              // validator: (value) => value!.isEmpty
                              //     ? "Please enter your user name"
                              //     : '',
                            onChanged: (val){
                              _onChanged(2, val);
                            },
                              controller: _userName,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                prefixIcon: Icon(Icons.person),
                                labelText: "User Name",
                                hintText: "Enter preffered user name",
                                // hintStyle: TextStyle(color: hintColor)
                              ))
                        ),
                        Container(
                          child: Text(message_2),
                        )

                        ,

                        //User email
                        Container(

                            padding: EdgeInsets.all( paddingValue),
                          child:TextFormField(
                              // validator: (value) => value!.isNotEmpty?emailValidator(value):'Please Enter Your Email',
                              controller: _userEmail,
                              onChanged: (val){
                                _onChanged(3, val);
                              },
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                prefixIcon: Icon(Icons.email),
                                labelText: "E-mail",
                                hintText: "Enter your e-mail",
                                // hintStyle: TextStyle(color: hintColor)
                              ))
                        ),
                        Container(
                          child: Text(message_3)
                        )
                        ,

                        //Password
                        Container(
                            padding: EdgeInsets.all( paddingValue),
                          child:TextFormField(
                              // validator: (value) => value!.length < 8
                              //     ? "Password should at least 8 characters"
                              //     : '',
                            onChanged: (val){
                              _onChanged(4, val);
                            },
                              controller: _password,
                              obscureText: _obscurity,
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.lock),
                                suffix: InkWell(
                                    onTap: _togglePasswordView,
                                    child: passwordSufixIcon()),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.white,
                                  ),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                labelText: "Password",
                                hintText: "Enter your password",
                              ))
                        ),
                        Container(
                          child: Text(message_4,
                          style: TextStyle(
                            color: Colors.redAccent
                          ),)
                        )

                        ,

                        //confirm password
                        Container(

                            padding: EdgeInsets.all( paddingValue),
                          child:TextFormField(
                              // validator: (value) => value!.isNotEmpty && value == _password.text
                              //     ? ''
                              //     : "Passwords do not match",
                            onChanged: (val){
                              _onChanged(5, val);
                            },
                              controller: _confirmPassword,
                              obscureText: _obscurity,
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.lock),
                                suffix: InkWell(
                                    onTap: _togglePasswordView,
                                    child: passwordSufixIcon()),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Colors.white,
                                  ),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                labelText: "Confirm Password",
                                hintText: "Confirm password",
                              ))
                        ),
                        Container(
                          child: Text(message_5,
                              style: TextStyle(
                                  color: Colors.redAccent
                              )),
                        )

                        ,

                        //call to actions
                        Container(

                            margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton(
                                      child: Text("Sign up"),
                                      onPressed: () async{
                                        if(emailValidator(_userEmail.text)==''){
                                          if(_password.text.length>=6){
                                            if(_password.text==_confirmPassword.text){
                                              if(_firstName.text.isNotEmpty && _lastName.text.isNotEmpty && _userName.text.isNotEmpty){
                                                if(await signUp(
                                                    _userEmail.text,
                                                    _firstName.text,
                                                    _lastName.text,
                                                    _userName.text,
                                                    _password.text,
                                                    _confirmPassword.text)=='forward'){
                                                  if(await sendCode(_userEmail.text)=='forward'){
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(builder: (context) => SignUpCodeConfirmationState(this._userEmail.text)),
                                                    );
                                                  }else{
                                                    //
                                                    ScaffoldMessenger.of(context).showSnackBar(
                                                      const SnackBar(
                                                          backgroundColor: Colors.black,
                                                          content: Text('Sign Up Error',
                                                          style: TextStyle(
                                                            color: Colors.orangeAccent
                                                          )
                                                          )
                                                      ),
                                                    );
                                                  }
                                                }else{
                                                  //todo error signing up
                                                  ScaffoldMessenger.of(context).showSnackBar(
                                                    const SnackBar(
                                                        backgroundColor: Colors.black,
                                                        content: Text('Error Receivig data',
                                                            style: TextStyle(
                                                                color: Colors.orangeAccent
                                                            ))),
                                                  );
                                                }
                                              }else{
                                                //todo names cannot be left empty
                                                ScaffoldMessenger.of(context).showSnackBar(
                                                  const SnackBar(
                                                      backgroundColor: Colors.black,
                                                      content: Text('Names cannot be left empty',
                                                          style: TextStyle(
                                                              color: Colors.orangeAccent
                                                          ))),
                                                );
                                              }
                                            }else{
                                              //todo passwords do not match
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                const SnackBar(
                                                    backgroundColor: Colors.black,
                                                    content: Text('Passwords do not match',
                                                        style: TextStyle(
                                                            color: Colors.orangeAccent
                                                        ))),
                                              );
                                            }
                                          }else{
                                            //todo password too short
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(
                                                  backgroundColor: Colors.black,
                                                  content: Text('Password too short, must be at least 6',
                                                      style: TextStyle(
                                                          color: Colors.orangeAccent
                                                      ))),
                                            );
                                          }
                                        }else{
                                          //todo fix email
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(
                                                backgroundColor: Colors.black,
                                                content: Text('Incorect Email Format',
                                                    style: TextStyle(
                                                        color: Colors.orangeAccent
                                                    ))),
                                          );
                                        }
                                      }, ),
                                  Container(
                                    width: 170,
                                    height: 30,
                                    color: Colors.grey.withOpacity(0),
                                    alignment: Alignment.center,
                                    margin: EdgeInsets.fromLTRB(50, 0, 0, 0),
                                    child: GestureDetector(
                                      onTap: () {
                                        Navigator.pop(context, "/");
                                      },
                                      child: Text("Already have an account"),
                                    ),
                                  )
                                ])),
                      ]))),
              // TextFieldState(
              //     _firstName, "First name", "Enter first name", nameIcon),
              // TextFieldState(_lastName, "Last name", "Enter last name", nameIcon),
              // TextFieldState(_userEmail, "E-mail", "Enter e-mail", emailIcon),
              // PasswordFieldState(
              //     _password, "Password", "Enter password", passwordIcon),
              // PasswordFieldState(
              //     _confirmPassword, "Confirm", "Confirm password", passwordIcon),
            ],
          )),
    );
  }
}
