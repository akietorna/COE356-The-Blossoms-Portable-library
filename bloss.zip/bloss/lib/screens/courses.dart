import 'package:flutter/material.dart';
import 'availablePrograms.dart';
import 'chosenCourse.dart';
import 'package:dio/dio.dart';
import 'toTitle.dart';
import 'package:url_launcher/url_launcher.dart';
// import 'package:path_provider/path_provider.dart' as p;

class Courses extends StatefulWidget {
  //late List list_of_courses;

  late String name;
  late int year;
  List year_convert = ['one', 'two', 'three', 'four'];

  Courses(name, year){
    this.name = name;
    this.year = year;
    //this.list_of_courses = programYearCourses[this.name][this.year.toString()];
  }

  @override
  State<Courses> createState() => _CoursesState();
}

class _CoursesState extends State<Courses> with TickerProviderStateMixin {
  //https://downgit.github.io/#/home?url={sub-repo}

  Future<void> _launchInWebView(String url) async {
    String trueRL = 'https://downgit.github.io/#/home?url=${url}';
    if (await canLaunch(trueRL)) {
      final lunch = await launch(
        trueRL,
        enableJavaScript: true,
        forceWebView: true,
        enableDomStorage: true,
      );
      print(launch);
    } else {
      throw 'Could not launch $url';
    }
  }

  final dio = Dio();
  late TabController _controller;
  int _initialTabIndex = 0;
  var _foundPrograms = [];

  int resolveSem(int year, int key){
    return (year-1)*2 +key+1;
  }

  Future<List> _getCoursesForProgramForSem(int sem,String program) async {
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}courses-for-program-for-sem?program=${program}&sem=${sem}';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      if(response.data!=null){
        return response.data!['Courses'] as List;
      }else{
        return [];
      }
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<Map> _getCourse(String code) async{
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}course?code=$code';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data[0] as Map;
    }
    catch(err){
      print(err);
      return {
        "about": "",
        "course_code":"",
        "name":""
      } as Map;
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _foundPrograms = list_of_Programs;
    _controller = TabController(length: 2, vsync: this);

    _controller.addListener(() {
      setState(() {
        print(_controller.index);
        _initialTabIndex = _controller.index;
      });
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: NestedScrollView(
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SliverAppBar(
                  automaticallyImplyLeading: false,
                  actions: [
                    //TODO: Quick search for course
                  ],
                  // title: ListTile(
                  //   title: Text(toTitle('${widget.name.toString()} Engineering'),
                  //   style: TextStyle(
                  //     fontWeight: FontWeight.w600,
                  //     fontSize: 20.0
                  //   ),),
                  //   subtitle: Text(toTitle('year ${widget.year_convert[widget.year-1]}')),
                  // ),
                  title: Column(
                    children: [
                      SizedBox(
                        height: 20.0,
                      ),
                      Container(
                        alignment: Alignment.topLeft,
                        child: Text(toTitle('${widget.name.toString()} Engineering Year ${widget.year}'),
                        style: TextStyle(
                          color: Colors.orangeAccent
                        )),
                      ),
                      SizedBox(
                        height: 5.0
                      ),
                      // Container(
                      //   alignment: Alignment.bottomLeft,
                      //   child: Text(toTitle('year ${widget.year_convert[widget.year-1]}'),
                      //   style: TextStyle(
                      //     fontSize: 10.0,
                      //     color: Colors.orange
                      //   ),),
                      // )
                    ],
                  ),
                  expandedHeight: 160.0,
                  pinned: true,
                  floating: true,
                  bottom: TabBar(
                    indicatorColor: Colors.orange,
                    controller: _controller,
                    onTap: (_) {
                      print('tapped ${_} page');
                    },
                    tabs: [
                      Tab(
                        child: Text('First Semester',
                            style: TextStyle(
                                color: Colors.orangeAccent
                            )),
                      ),
                      Tab(
                        child: Text('Second Semester',
                            style: TextStyle(
                                color: Colors.orangeAccent
                            )),
                      )
                    ],
                  ),
                )
              ];
            },
            body: TabBarView(
              controller: _controller,
              children: [

                FutureBuilder(
                    future: _getCoursesForProgramForSem(resolveSem(widget.year, 0), widget.name),
                    builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                        snapshot.hasData?
                        ListView.builder(
                            itemCount: snapshot.data!.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Card(
                                child: Container(
                                  child: ListTile(
                                    onTap: () {

                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(builder: (context)=>
                                              ChosenCourse('${snapshot.data![index]['course_code'].toString()}', widget.name, resolveSem(widget.year, 0))
                                      ));

                                      print(
                                          'course ${snapshot.data![index]['course_code']} was pressed');
                                    },
                                    title: Text(toTitle(snapshot.data![index]['course_code'].split("/").last),
                                    style: TextStyle(
                                      color: Colors.orangeAccent
                                    ),),
                                    // subtitle: FutureBuilder(
                                    //     future: _getCourse(snapshot.data![index]['course_code']),
                                    //     builder: (BuildContext ctx, AsyncSnapshot<Map> snapshot)=>
                                    //         snapshot.hasData?
                                    //             Text(snapshot.data!['name']):
                                    //         Center(
                                    //           child: SizedBox(
                                    //             child: CircularProgressIndicator(),
                                    //             height: 15.0,
                                    //             width: 15.0,
                                    //           ),
                                    //         )
                                    //
                                    // ),
                                    trailing: IconButton(
                                      onPressed: () async{
                                        String url = 'https://github.com${snapshot.data![index]['course_code']}';
                                        print(url);
                                        await _launchInWebView(url);
                                      },
                                      icon: Icon(Icons.cloud_download,
                                        color: Colors.black,),
                                    )
                                  ),
                                ),
                              );
                            }):
                        Center(
                          child: SizedBox(
                            child: CircularProgressIndicator(),
                            height: 30.0,
                            width: 30.0,
                          ),
                        )
                ),

                FutureBuilder(
                    future: _getCoursesForProgramForSem(resolveSem(widget.year, 1), widget.name),
                    builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                    snapshot.hasData?
                    ListView.builder(
                        itemCount: snapshot.data!.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Card(
                            child: Container(
                              child: ListTile(
                                onTap: () {

                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context)=>
                                          ChosenCourse('${snapshot.data![index]['course_code']}',  widget.name, resolveSem(widget.year, 1)))
                                  );

                                  print(
                                      'course ${snapshot.data![index]['course_code']} was pressed');
                                },
                                title: Text(toTitle(snapshot.data![index]['course_code'].split("/").last),
                                    style: TextStyle(
                                        color: Colors.orangeAccent
                                    )),
                                // subtitle: FutureBuilder(
                                //     future: _getCourse(snapshot.data![index]['course_code']),
                                //     builder: (BuildContext ctx, AsyncSnapshot<Map> snapshot)=>
                                //     snapshot.hasData?
                                //     Text(snapshot.data!['name']):
                                //     Center(
                                //       child: SizedBox(
                                //         child: CircularProgressIndicator(),
                                //         height: 15.0,
                                //         width: 15.0,
                                //       ),
                                //     )
                                //
                                // ),
                                trailing: IconButton(
                                  onPressed: () async{
                                    String url = 'https://github.com${snapshot.data![index]['course_code']}';
                                    print(url);
                                    await _launchInWebView(url);
                                  },
                                  icon: Icon(Icons.cloud_download,
                                    color: Colors.black,),
                                ),
                              ),
                            ),
                          );
                        }):
                    Center(
                      child: SizedBox(
                        child: CircularProgressIndicator(),
                        height: 30.0,
                        width: 30.0,
                      ),
                    )
                ),

                // ListView.builder(
                //     itemCount: widget.list_of_courses[0].length,
                //     itemBuilder: (BuildContext context, int index) {
                //       return Card(
                //         child: Container(
                //           child: ListTile(
                //             onTap: () {
                //
                //               Navigator.push(
                //                   context,
                //                   MaterialPageRoute(builder: (context)=>
                //                       ChosenCourse('${widget.list_of_courses[0][index].toString()}'))
                //               );
                //
                //               print(
                //                   'course ${courses_materials[widget.list_of_courses[0][index]]['about']['name']} was pressed');
                //             },
                //             title: Text(widget.list_of_courses[0][index]),
                //             subtitle: Text(courses_materials[widget
                //                 .list_of_courses[0][index]]['about']['name']),
                //             trailing: Icon(Icons.download_outlined),
                //           ),
                //         ),
                //       );
                //     }),
                // ListView.builder(
                //     itemCount: widget.list_of_courses[1].length,
                //     itemBuilder: (BuildContext context, int index) {
                //       return Card(
                //         child: Container(
                //           child: ListTile(
                //             onTap: () {
                //
                //               Navigator.push(
                //                 context,
                //                 MaterialPageRoute(builder: (context)=>
                //                 ChosenCourse(widget.list_of_courses[1][index].toString()
                //                 )
                //                 )
                //               );
                //
                //               print(
                //                   'course ${courses_materials[widget.list_of_courses[1][index]]['about']['name']} was pressed');
                //             },
                //             title: Text(widget.list_of_courses[1][index]),
                //             subtitle: Text(courses_materials[widget
                //                 .list_of_courses[1][index]]['about']['name']),
                //             trailing: Icon(Icons.download_outlined),
                //           ),
                //         ),
                //       );
                //     }),
              ],
            )),
      ),
    );
  }
}
