import "package:flutter/material.dart";
import 'logo.dart';
import "main.dart";
import "backgroundoverlay.dart";
import 'package:dio/dio.dart';
import 'passwordResetPage.dart';

class CodeConfirmationState extends StatefulWidget {
  late String mail;
  CodeConfirmationState(this.mail);
  @override
  State<StatefulWidget> createState() {
    return CodeConfirmation(this.mail);
  }
}

class CodeConfirmation extends State<CodeConfirmationState> {
  late String email;
  CodeConfirmation(this.email);
  TextEditingController codeConfirmation = TextEditingController();
  Widget codeConfirmationIcon = Icon(Icons.coronavirus);

  Future<String> checkEmailAndPassValidity(String email) async{
    final api = 'http://slydhub.pythonanywhere.com/forget_password/';
    var dio = Dio();
    print('$email');

    if(email.contains('@') && email.contains('.')){
      if(email.indexOf('.')>email.indexOf('@')){
        print('format ok');
        try{
          final response = await dio.request(
            api,
            data: {'email':email},
            options: Options(
                followRedirects: false,
                validateStatus: (status) { return status! < 500; },

                method:'POST'),
          );
          print(response.data);
          if (response.data['status']=='email sent'){
            return 'forward';
          }else{
            return 'error';
          }
        }
        catch(err){
          print(err);
          return 'error';
        }
      }else{
        return 'Incorrect email format';
      }
    }
    else{

      return 'Incorrect email format';
    }
  }

  Future<String> checkCode(String code) async{
    final api = 'http://slydhub.pythonanywhere.com/confirm_reset/';
    var dio = Dio();
    print('$code');

        try{
          final response = await dio.request(
            api,
            data: {'confirm_code':code},
            options: Options(
                followRedirects: false,
                validateStatus: (status) { return status! < 500; },

                method:'POST'),
          );
          print(response.data);
          //todo somethhing
          if (response.data["status"]=='code confirmed'){
            return 'forward';
          }else{
            return 'error';
          }
        }
        catch(err){
          print(err);
          return 'error';
        }
      }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   title: Text("Confirm code"),
        //   centerTitle: true,
        //  // backgroundColor: appBarColor,
        // ),
        body: ListView(children: [
          SizedBox(
            height: 30.0
          ),
          Container(
            alignment: Alignment.center,
            child: Text(
              'Confirm code',
                style: TextStyle(
                  fontSize: 30.0,
                       color: Colors.orangeAccent
                   ),
            )
          ),
          SizedBox(
            height: 15.0
          ),
          LogoImage("./assets/images/code.png"),
          SizedBox(
            height: 30.0
          ),
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.all(15),
            child: TextFormField(
              autofocus: true,
              controller: codeConfirmation,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderSide: BorderSide(

                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                prefixIcon: codeConfirmationIcon,
                labelText: "Confirm code",
                hintText: "Enter the confirmation code",

              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              RaisedButton(
                  child: Text("Submit"),
                  onPressed: () async{
                    if(await checkCode(codeConfirmation.text.toString())=='forward'){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => PasswordResetState(email)
                    ));
                    }else{
                      final snackBar = SnackBar(
                        content: Text('Failed',
                            style: TextStyle(
                                color: Colors.orangeAccent
                            )),
                        backgroundColor: Colors.black,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    }
                  },
                  ),
              Container(
                margin: EdgeInsets.fromLTRB(50, 0, 0, 0),
                child: ElevatedButton(
                  onPressed: () async{
                    if(await checkEmailAndPassValidity(this.email)=='forward'){
                      final snackBar = SnackBar(
                        content: Text('Code Resent',
                            style: TextStyle(
                                color: Colors.orangeAccent
                            )),
                        backgroundColor: Colors.black,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    }else{
                      final snackBar = SnackBar(
                        content: Text('Code Could not be Sent',
                            style: TextStyle(
                                color: Colors.orangeAccent
                            )),
                        backgroundColor: Colors.black,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    }

                  },
                    child: Text("Resend code")
                ),
              )
            ],
          )
        ]));
  }
}
