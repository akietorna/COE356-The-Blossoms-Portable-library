import 'toTitle.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart' as p;
import 'dart:io';
import 'package:open_file/open_file.dart';

class ChosenCourse extends StatefulWidget {
  //List list_of_courses;
  late String course_code;
  late String program;
  late int sem;

  ChosenCourse(this.course_code, this.program, this.sem);

  @override
  _ChosenCourseState createState() => _ChosenCourseState();
}

class _ChosenCourseState extends State<ChosenCourse>
    with TickerProviderStateMixin {
  final dio = Dio();


//TabController had late before it
  late TabController _controller;
  int _initialTabIndex = 0;
  //var _foundPrograms = [];
  late String slydehub;
  void setSlyde()async{
    var sl = await p.getExternalStorageDirectories();
    var part = await sl!.first.path.toString().split('/');
    for(int i=0;i<4;i++){
      part.removeLast();
    }
    String temp = part.join('/');
    setState(() {
      slydehub = '$temp/Slydehub';
    });
  }


  Future<void> openFile(filePath) async {
    OpenFile.open(filePath);
  }

  Future<String> download2(String url, String fileName, String code, String prog, String sem, String category) async {
    final download_dio = Dio();
    final dirList = await p.getExternalStorageDirectory();
    //final dirList = await p.getApplicationDocumentsDirectory();
    final path = '${dirList!.path}/$prog/$sem/$code/$category';
    print(path);



    bool directoryExist = await Directory(
      '$path'
    ).exists();

    if(directoryExist){
      print('dir exists');
        final already_exists = '$path/$fileName';
        bool fileExists = await File(already_exists).exists();

        if(fileExists){
          final snackBar = SnackBar(
          content: Text('$fileName already exists',
              style: TextStyle(
                  color: Colors.orangeAccent
              )),
          backgroundColor: Colors.black,
        );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
          print('file already exist');
          return '';
      }
        else{

          // var status = await Permission.storage.status;
          // if (!status.isGranted) {
          //   await Permission.storage.request();
          // }
          print('file no exist');
          print(fileName);

          try {
            Response response = await download_dio.get(
              url,
              onReceiveProgress: showDownloadProgress,
              //Received data with List<int>
              options: Options(
                  responseType: ResponseType.bytes,
                  followRedirects: true,
                  validateStatus: (status) {
                    return status! < 500;
                  }),
            );
            //print(response.headers);


            File file = File('$path/$fileName');
            file.createSync(recursive: true);
            file.writeAsBytes(response.data);
            //var raf = file.openSync(mode: FileMode.write);
            // response.data is List<int> type
            //raf.writeByte(response.data);
            //await raf.close();

            setState(() {
              filefullPath = file.path;
            });


            print(filefullPath);
            final snackBar = SnackBar(
              content: Text('$fileName downloaded',
                  style: TextStyle(
                      color: Colors.orangeAccent
                  )),
              backgroundColor: Colors.black,
            );
            ScaffoldMessenger.of(context).showSnackBar(snackBar);


            return filefullPath;

          // try{
          //   final taskId = await FlutterDownloader.enqueue(
          //     url: '$url',
          //     savedDir: '$path$fileName',
          //     showNotification: true, // show download progress in status bar (for Android)
          //     openFileFromNotification: true, // click on notification to open downloaded file (for Android)
          //
          //   );
          //   return '';
          } catch (e) {
            print(e);
            return '';
          }
        }
    }
    else{
      print('dir no exist');

      // var status = await Permission.storage.status;
      // if (!status.isGranted) {
      //   await Permission.storage.request();
      // }
      Directory creatingDir = await Directory(
          '$path'
      ).create(recursive: true);

      try {
        Response response = await download_dio.get(
          url,
          onReceiveProgress: showDownloadProgress,
          //Received data with List<int>
          options: Options(
              responseType: ResponseType.bytes,
              followRedirects: true,
              validateStatus: (status) {
                return status! < 500;
              }),
        );
        //print(response.headers);


        File file = File('$path/$fileName');
        file.createSync(recursive: true);
        file.writeAsBytes(response.data);

        setState(() {
          filefullPath = file.path;
        });


        print(filefullPath);
        final snackBar = SnackBar(
          content: Text('$fileName downloaded',
              style: TextStyle(
                  color: Colors.orangeAccent
              )),
          backgroundColor: Colors.black,
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);


        return filefullPath;
      } catch (e) {
        print(e);
        return '';
      }
    }
  }

  void showDownloadProgress(received, total) {
    if (total != -1) {
      print((received / total * 100).toStringAsFixed(0) + "%");
      setState(() {
        isLoading = true;
        progress = (received/total) * 100;

      });
    }
  }

  Future downloadAndSaveFiletoStorage(String url, String fileName) async{

    try{
      final dirList = await p.getDownloadsDirectory();
      final path = await dirList!.path;
      final file = File('$path/$fileName');
      await dio.download(url, file.path,
          onReceiveProgress: (rec, total){
            setState(() {
              isLoading = true;
              progress = (rec/total) * 100;
              print(progress);
            });
          });

      setState(() {
        filefullPath = file.path;
      });
    }catch(e){
      print(e);
    }
    if(progress == 100) {
      print(filefullPath);
    }

  }


  Future<List> _getBooksForCourse(String code) async {
    final books_dio = Dio();
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}books-for-a-course?course_code=$code';
    final tweak = '${base}/books-courses';
    try{
      final response = await books_dio.request(
        tweak,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      final tweak_result = response.data['books-courses'] as List;
      return tweak_result.where(
              (element) => element['course_code']==code).toList();
      //return response.data['Books'] as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _infoBook(String link) async {
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}book?link=$link';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _getPrepsForCourse(String code) async {
    final preps_dio = Dio();
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}preps-for-course?course_code=$code';
    try{
      final response = await preps_dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data['Preps'] as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _infoPrep(String link) async {
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}prep?link=$link';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data['Prep'] as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _getVidsForCourse(String code) async {
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}videos-for-a-course?course_code=$code';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data['videos'] as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _infoVid(String link) async {
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}video?link=$link';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _getSlidesForCourse(String code) async {
    final slides_dio = Dio();
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}slides-for-a-course?course_code=$code';
    try{
      final response = await slides_dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);

      if(response.data!=null){
        return response.data['slides'] as List;
      }else{
        return [];
      }
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _infoSlide(String link) async {
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}slide?link=$link';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data['slides'] as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _getProjectsForCourse(String code) async {
    final projects_dio = Dio();
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}projects-for-a-course?course_code=$code';
    try{
      final response = await projects_dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data['Projects for ${code}'] as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  Future<List> _infoProject(String link) async {
    final base = 'http://ewinLab.pythonanywhere.com/';
    final api = '${base}project?link=$link';
    try{
      final response = await dio.request(
        api,
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'GET'),
      );
      //print(response.data);
      return response.data['Project'] as List;
    }
    catch(err){
      print(err);
      return [];
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = TabController(length: 4, vsync: this);
    setSlyde();

    _controller.addListener(() {
      setState(() {
        print(_controller.index);
        _initialTabIndex = _controller.index;
      });
    });
  }

  //get storage permission

  @override
  void dispose() {
    // TODO: implement dispose
    _controller.dispose();
    super.dispose();
  }

  var isLoadingMap = Map();
  late List<String> filefullPathList;
  var progressMap = Map();

  //progressMap['Slides'] = 2;
  late String filefullPath;
  bool isLoading = false;
  double progress = 0.0;
  String urlPdf = 'https://github.com/akietorna/COE356-The-Blossoms-Portable-library/raw/main/Prototype/Project_Prototype.pdf';
  String url2 = 'https://github.com/akietorna/COE356-The-Blossoms-Portable-library/raw/front_end/Gryffin%20-%20Tie%20Me%20Down%20(Lyrics)%20ft.%20Elley%20Duh%C3%A9-_niG5GJ6eto.m4a';
  String url3 = 'https://github.com/akietorna/COE356-The-Blossoms-Portable-library/raw/front_end/photo.jpg';

  @override
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        body: NestedScrollView(
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SliverAppBar(
                  automaticallyImplyLeading: false,
                  actions: [
                    //TODO: Quick search for course
                  ],
                  title: ListTile(
                    //todo name of course
                    title: Text(toTitle(widget.course_code.split('/').last),
                        style: TextStyle(
                            color: Colors.orange
                        )),
                    trailing: progress==0.0?SizedBox(
                      width:0.0
                    ):Text('${progress.toStringAsFixed(1)} %',
                        style: TextStyle(
                            color: Colors.orange
                        ))
                    //todo course code
                  ),
                  expandedHeight: 130.0,
                  pinned: true,
                  floating: true,
                  bottom: TabBar(
                    indicatorColor: Colors.orange,
                    controller: _controller,
                    onTap: (_) {
                      print('tapped ${_} page');
                    },
                    tabs: [
                      Tab(
                        child: Text('Books',
                            style: TextStyle(
                                color: Colors.orange
                            )),
                      ),
                      Tab(
                        child: Text('Slides',
                            style: TextStyle(
                                color: Colors.orange
                            )),
                      ),
                      Tab(
                        child: Text('Preps',
                            style: TextStyle(
                                color: Colors.orange
                            )),
                      ),
                      Tab(child: Text('Projects',
                          style: TextStyle(
                              color: Colors.orange
                          ))),
                      // Tab(
                      //   child: Text('Videos'),
                      // )
                    ],
                  ),
                )
              ];
            },
            body: TabBarView(
              controller: _controller,
              children: [
                //todo books
                Container(
                  //color: Colors.pinkAccent,
                  child: FutureBuilder(
                      future: _getBooksForCourse(widget.course_code),
                      builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                      snapshot.hasData?
                      (snapshot.data!.length>0?
                      ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (BuildContext context, int index) {
                            return Card(
                              child: Container(
                                child: ListTile(
                                    title: Text('${toTitle(snapshot.data![index]['link']).split('/').last}',
                                        style: TextStyle(
                                            color: Colors.orangeAccent
                                        )),

                                    trailing: IconButton(
                                      icon: Icon(Icons.download,

                                        color: Colors.black,),
                                      onPressed: () async{
                                        final dirList = await p.getExternalStorageDirectory();
                                        //final dirList = await p.getApplicationDocumentsDirectory();
                                        final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Books';
                                        final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                        //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                        if(!(await File('$file').existsSync())){
                                          print('no where to be found');
                                          String response = await download2(
                                              snapshot.data![index]['link'],
                                              snapshot.data![index]['link'].split('/').last,
                                              widget.course_code.split('/').last, widget.program, widget.sem.toString(), 'Books');
                                        }else{
                                          final snackBar = SnackBar(
                                            content: Text('Book already downloaded',
                                              style: TextStyle(
                                                  color: Colors.orangeAccent
                                              ),),
                                            backgroundColor: Colors.black,
                                          );
                                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                        }


                                        setState(() {
                                          progress = 0.0;
                                        });
                                      },
                                    ),
                                  onTap: ()async{
                                    final dirList = await p.getExternalStorageDirectory();
                                    //final dirList = await p.getApplicationDocumentsDirectory();
                                    final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Books';
                                    final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                    //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                    if(!(await File('$file').existsSync())){
                                      final snackBar = SnackBar(
                                        content: Text('${snapshot.data![index]['link'].split('/').last} has\'nt been downloaded',
                                          style: TextStyle(
                                              color: Colors.orangeAccent
                                          ),),
                                        backgroundColor: Colors.black,
                                      );
                                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                    }else{
                                      await openFile('$path/${snapshot.data![index]['link'].split('/').last}');
                                    }
                                  }

                                ),
                              ),
                            );
                          }):
                      Container()):
                      Center(
                        child: SizedBox(
                          child: CircularProgressIndicator(),
                          height: 30.0,
                          width: 30.0,
                        ),
                      )
                  ),
                ),

                //todo slides
                Container(
                  color: Colors.transparent,
                  child: FutureBuilder(
                      future: _getSlidesForCourse(widget.course_code),
                      builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                      snapshot.hasData?
                      (snapshot.data!.length>0?
                      ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (BuildContext context, int index) {
                            late bool existence;
                            // void initexist()async{
                            //   setState(() {
                            //     existence = await exixt('$slydehub/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/${snapshot.data![index]['link'].split('/').last}').then((value) => value);
                            //   });
                            // }

                            return Card(
                              child: Container(
                                child: ListTile(
                                  title: Text('${toTitle(snapshot.data![index]['link'].split('/').last)}',
                                      style: TextStyle(
                                          color: Colors.orangeAccent
                                      )),

                                  trailing: RawMaterialButton(
                                    child: Icon(
                                      Icons.download,
                                      color: Colors.black,
                                    ),
                                    onPressed: () async{

                                      print('slidehub: $slydehub');

                                      final dirList = await p.getExternalStorageDirectory();
                                      //final dirList = await p.getApplicationDocumentsDirectory();
                                      final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Slides';
                                      final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                      //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                      if(!(await File('$file').existsSync())){
                                        print('no where to be found');
                                        String response = await download2(
                                            snapshot.data![index]['link'],
                                            snapshot.data![index]['link'].split('/').last,
                                            widget.course_code.split('/').last, widget.program, widget.sem.toString(), 'Slides');
                                      }else{
                                        final snackBar = SnackBar(
                                          content: Text('Slide already downloaded',
                                            style: TextStyle(
                                                color: Colors.orangeAccent
                                            ),),
                                          backgroundColor: Colors.black,
                                        );
                                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                      }


                                      setState(() {
                                        progress = 0.0;
                                      });
                                    },
                                  ),


                                    onTap: ()async{
                                      final dirList = await p.getExternalStorageDirectory();
                                      //final dirList = await p.getApplicationDocumentsDirectory();
                                      final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Slides';
                                      final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                   //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                   if(!(await File('$file').existsSync())){
                                     final snackBar = SnackBar(
                                       content: Text('${snapshot.data![index]['link'].split('/').last} has\'nt been downloaded',
                                         style: TextStyle(
                                             color: Colors.orangeAccent
                                         ),),
                                       backgroundColor: Colors.black,
                                     );
                                     ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                   }else{
                                     await openFile('$path/${snapshot.data![index]['link'].split('/').last}');
                                   }
                                  }

                                ),
                              ),
                            );
                          }):
                      Container()):
                      Center(
                        child: SizedBox(
                          child: CircularProgressIndicator(),
                          height: 30.0,
                          width: 30.0,
                        ),
                      )
                  )
                ),

                //todo preps
                Container(
                  //color: Colors.tealAccent,
                    child: FutureBuilder(
                        future: _getPrepsForCourse(widget.course_code),
                        builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                        snapshot.hasData?
                        (snapshot.data!.length>0?
                        ListView.builder(
                            itemCount: snapshot.data!.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Card(
                                child: Container(
                                  child: ListTile(
                                      title: Text('${toTitle(snapshot.data![index]['link'].split('/').last)}',
                                          style: TextStyle(
                                              color: Colors.orangeAccent
                                          )),

                                      trailing: IconButton(
                                        icon: Icon(Icons.download,

                                          color: Colors.black,),
                                        onPressed: () async{
                                          final dirList = await p.getExternalStorageDirectory();
                                          //final dirList = await p.getApplicationDocumentsDirectory();
                                          final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Preps';
                                          final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                          //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                          if(!(await File('$file').existsSync())){
                                            print('no where to be found');
                                            String response = await download2(
                                                snapshot.data![index]['link'],
                                                snapshot.data![index]['link'].split('/').last,
                                                widget.course_code.split('/').last, widget.program, widget.sem.toString(), 'Preps');
                                          }else{
                                            final snackBar = SnackBar(
                                              content: Text('Preparational material already downloaded',
                                                style: TextStyle(
                                                    color: Colors.orangeAccent
                                                ),),
                                              backgroundColor: Colors.black,
                                            );
                                            ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                          }


                                          setState(() {
                                            progress = 0.0;
                                          });
                                        },
                                      ),

                                    onTap: ()async{
                                      final dirList = await p.getExternalStorageDirectory();
                                      //final dirList = await p.getApplicationDocumentsDirectory();
                                      final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Preps';
                                      final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                      //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                      if(!(await File('$file').existsSync())){
                                        final snackBar = SnackBar(
                                          content: Text('${snapshot.data![index]['link'].split('/').last} has\'nt been downloaded',
                                            style: TextStyle(
                                                color: Colors.orangeAccent
                                            ),),
                                          backgroundColor: Colors.black,
                                        );
                                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                      }else{
                                        await openFile('$path/${snapshot.data![index]['link'].split('/').last}');
                                      }
                                    }
                                  ),
                                ),
                              );
                            }):
                        Container()):
                        Center(
                          child: SizedBox(
                            child: CircularProgressIndicator(),
                            height: 30.0,
                            width: 30.0,
                          ),
                        )
                    )
                ),

                //todo projects
                Container(
                  //color: Colors.transparent,
                    child: FutureBuilder(
                        future: _getProjectsForCourse(widget.course_code),
                        builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                        snapshot.hasData?
                        (snapshot.data!.length>0?
                        ListView.builder(
                            itemCount: snapshot.data!.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Card(
                                child: Container(
                                  child: ListTile(
                                      title: Text('${toTitle(snapshot.data![index]['link'].split('/').last)}',
                                          style: TextStyle(
                                              color: Colors.orangeAccent
                                          )),

                                      trailing: IconButton(
                                          icon: Icon(Icons.download,
                                          color: Colors.black,),
                                        onPressed: ()async{
                                          final dirList = await p.getExternalStorageDirectory();
                                          //final dirList = await p.getApplicationDocumentsDirectory();
                                          final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Projects';
                                          final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                          //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                          if(!(await File('$file').existsSync())){
                                            print('no where to be found');
                                            String response = await download2(
                                                snapshot.data![index]['link'],
                                                snapshot.data![index]['link'].split('/').last,
                                                widget.course_code.split('/').last, widget.program, widget.sem.toString(), 'Projects');
                                          }else{
                                            final snackBar = SnackBar(
                                              content: Text('Project already downloaded',
                                                style: TextStyle(
                                                    color: Colors.orangeAccent
                                                ),),
                                              backgroundColor: Colors.black,
                                            );
                                            ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                          }


                                          setState(() {
                                            progress = 0.0;
                                          });
                                        },
                                      ),


                                          onTap: ()async{
                                            final dirList = await p.getExternalStorageDirectory();
                                            //final dirList = await p.getApplicationDocumentsDirectory();
                                            final path = '${dirList!.path}/${widget.program}/${widget.sem}/${widget.course_code.split('/').last}/Projects';
                                            final file = '$path/${snapshot.data![index]['link'].split('/').last}';

                                            //final existense = await exixt('$path/${snapshot.data![index]['link'].split('/').last}');
                                            if(!(await File('$file').existsSync())){
                                          final snackBar = SnackBar(
                                            content: Text('${snapshot.data![index]['link'].split('/').last} has\'nt been downloaded',
                                              style: TextStyle(
                                                  color: Colors.orangeAccent
                                              ),),
                                            backgroundColor: Colors.black,
                                          );
                                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                        }else{
                                          await openFile('$path/${snapshot.data![index]['link'].split('/').last}');
                                        }
                                      }

                                  ),
                                ),
                              );
                            }):
                        Container()):
                        Center(
                          child: SizedBox(
                            child: CircularProgressIndicator(),
                            height: 30.0,
                            width: 30.0,
                          ),
                        )
                    )
                ),

                // //todo videos
                // Container(
                //   color: Colors.deepOrangeAccent,
                //     child: FutureBuilder(
                //         future: _getVidsForCourse(widget.course_code),
                //         builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                //         snapshot.hasData?
                //         ListView.builder(
                //             itemCount: snapshot.data!.length,
                //   The minCompileSdk (31) specified in a
                //      dependency's AAR metadata (META-INF/com/android/build/gradle/aar-metadata.properties)
                //      is greater than this module's compileSdkVersion (android-30)          itemBuilder: (BuildContext context, int index) {
                //               return Card(
                //                 child: Container(
                //                   child: FutureBuilder(
                //                     future: _infoVid(snapshot.data![index]['link']),
                //                     builder: (BuildContext ctx, AsyncSnapshot<List> snapshot)=>
                //                         snapshot.hasData?
                //                             ListTile(
                //               title: Text('${snapshot.data![index]['name']}',
                //               style: TextStyle(
                //               color: Colors.orangeAccent
                //               )),
                //               subtitle: Text('${snapshot.data![index]['creator']}',
                //               style: TextStyle(
                //               )),
                //               trailing: Icon(Icons.download,
                //               color: Colors.black,),
                //
                //                               onTap: ()async{
                //                                 final dirList = await p.getExternalStorageDirectories();
                //                                 //final dirList = await p.getApplicationDocumentsDirectory();
                //                                 final path = await dirList!.first.path;
                //
                //                                 final existense = await exixt('$path${snapshot.data![index]['name']}');
                //                                 if(!existense){
                //                                   final snackBar = SnackBar(
                //                                     content: Text('${snapshot.data![index]['name']} has\'nt been downloaded',
                //                                       style: TextStyle(
                //                                           color: Colors.orangeAccent
                //                                       ),),
                //                                     backgroundColor: Colors.black,
                //                                   );
                //                                   ScaffoldMessenger.of(context).showSnackBar(snackBar);
                //                                 }else{
                //                                   await openFile('$path${snapshot.data![index]['name']}');
                //                                 }
                //                               }
                //               ):
                //               Center(
                //               child: SizedBox(
                //               child: CircularProgressIndicator(),
                //               height: 30.0,
                //               width: 30.0,
                //               )
                //                   ),
                //                 ),
                //               ));
                //             }):
                //         Center(
                //           child: SizedBox(
                //             child: CircularProgressIndicator(),
                //             height: 30.0,
                //             width: 30.0,
                //           ),
                //         )
                //     )
                // )
              ],
            )),
      ),
    );
  }


}

Future<bool> exixt(path) async{
  // final already_exists = '$path';
  bool fileExists = await File(path).exists();

  if(fileExists){
    // final snackBar = SnackBar(
    //   content: Text('$fileName already exists',
    //       style: TextStyle(
    //           color: Colors.orangeAccent
    //       )),
    //   backgroundColor: Colors.black,
    //  );
    // ScaffoldMessenger.of(context).showSnackBar(snackBar);
    print('alreadt exist');
    return true;
  }
  print('no exist');
  return false;
}

