String toTitle(String input) {
  final List<String> splitStr = input.split(' ');
  for (int i = 0; i < splitStr.length; i++) {
    splitStr[i] =
    '${splitStr[i][0].toUpperCase()}${splitStr[i].substring(1).toLowerCase()}';
  }
  final output = splitStr.join(' ');
  return output;
}