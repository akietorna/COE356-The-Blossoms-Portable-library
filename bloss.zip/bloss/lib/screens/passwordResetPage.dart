import 'package:flutter/material.dart';
import "logo.dart";
import 'package:dio/dio.dart';
import 'login.dart';

class PasswordResetState extends StatefulWidget {
  late String mail;
  PasswordResetState(this.mail);

  @override
  State<StatefulWidget> createState() {
    return PasswordReset(this.mail);
  }
}

class PasswordReset extends State<PasswordResetState> {
  late String mail;
  String message = '';

  PasswordReset(this.mail);

  bool _obscurity = true;

  Widget passwordSufixIcon() {
    if (_obscurity == true) {
      return Icon(Icons.visibility_off);
    } else {
      return Icon(Icons.visibility);
    }
  }

  void _togglePasswordView() {
    setState(() {
      _obscurity = !_obscurity;
    });
  }

  TextEditingController _newPassword = TextEditingController();
  TextEditingController _confirmNewPassword = TextEditingController();

  Future<String> checkCode(String pass, confPass) async{
    final api = 'http://slydhub.pythonanywhere.com/set_password/';
    var dio = Dio();

if (pass == confPass){
  setState(() {
    message = '';
  });
  if(pass.length>5){
    try{
      final response = await dio.request(
        api,
        data: {'email':this.mail,
          'password':pass,
          'confirm_password':confPass},
        options: Options(
            followRedirects: false,
            validateStatus: (status) { return status! < 500; },

            method:'POST'),
      );
      print(response.data);
      //todo somethhing
      if (response.data=='Password sucessfully resetted'){
        return 'forward';
      }else{
        return 'error';
      }
    }
    catch(err){
      print(err);
      return 'error';
    }
  }else{
    setState(() {
      message = 'Pasword must be at Least 6 characters';
    });
    return 'error';
  }
}else{
  setState(() {
    message = 'The two fields must be the same';
  });
  return 'error';
}
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: ListView(
          children: [
            SizedBox(
                height: 30.0
            ),
            Container(
                alignment: Alignment.center,
                child: Text(
                  'Password Reset',
                  style: TextStyle(
                      fontSize: 30.0,
                      color: Colors.orangeAccent
                  ),
                )
            ),


            LogoImage("./assets/images/forgotpassword.png"),
            Center(
              child: Container(
                margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                child: Center(child: Text("Reset password below")),
              ),
            ),
            // PasswordFieldState(_newPassword, "New password",
            //     "Enter your new password", passwordIcon),
            // PasswordFieldState(_confirmNewPassword, "Confirm new password",
            //     "Confirm your new password", passwordIcon),
            Container(
                padding:EdgeInsets.all(15),
                child:TextFormField(
                autofocus: true,
                controller: _newPassword,
                obscureText: _obscurity,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock),
                  suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: passwordSufixIcon()),
                  border: OutlineInputBorder(
                    borderSide: BorderSide
                      (
                    ),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  labelText: "Enter new password",
                  hintText: "Enter your new password",
                ))
            )

            ,
            Container(
                padding:EdgeInsets.all(15),
                child:TextFormField(
                validator: (value) => value==_newPassword
                    ? "Passwords do not match"
                    : null,
                controller: _confirmNewPassword,
                obscureText: _obscurity,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock),
                  suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: passwordSufixIcon()),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  labelText: "Confirm new password",
                  hintText: "Confirm enter your new password",
                ))
            ),

            // Container(
            //   alignment: Alignment.center,
            //   child: Text(message),),

            SizedBox(
              height: 20.0,
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                    child: Text("Submit"),
                    onPressed: () async{

                        if(await checkCode(_newPassword.text, _confirmNewPassword.text)=='forward'){
                          Navigator.of(context).popUntil((route) => route.isFirst);
                          Navigator.pushReplacement(
                              context, MaterialPageRoute(builder: (BuildContext context) => LoginPageState()));
                        }else{
                          final snackBar = SnackBar(
                            content: Text('$message',
                                style: TextStyle(
                                    color: Colors.orangeAccent
                                )),
                            backgroundColor: Colors.black,
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        }

                      },
                   
                    ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
