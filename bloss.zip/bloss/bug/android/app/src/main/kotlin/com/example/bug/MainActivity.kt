package com.example.bug

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
