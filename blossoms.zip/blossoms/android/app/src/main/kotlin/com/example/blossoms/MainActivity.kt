package com.example.blossoms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
