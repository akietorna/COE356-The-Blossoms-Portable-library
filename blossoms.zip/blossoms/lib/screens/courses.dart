import 'package:flutter/material.dart';
import 'availablePrograms.dart';
import 'chosenCourse.dart';

class Courses extends StatefulWidget {
  late List list_of_courses;

  late String name;
  late int year;
  List year_convert = ['one', 'two', 'three', 'four'];

  Courses(name, year){
    this.name = name;
    this.year = year;
    this.list_of_courses = programYearCourses[this.name][this.year.toString()];
  }

  @override
  State<Courses> createState() => _CoursesState();
}

class _CoursesState extends State<Courses> with TickerProviderStateMixin {
  late TabController _controller;
  int _initialTabIndex = 0;
  var _foundPrograms = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _foundPrograms = list_of_Programs;
    _controller = TabController(length: 2, vsync: this);

    _controller.addListener(() {
      setState(() {
        print(_controller.index);
        _initialTabIndex = _controller.index;
      });
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: NestedScrollView(
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SliverAppBar(
                  automaticallyImplyLeading: false,
                  actions: [
                    //TODO: Quick search for course
                  ],
                  title: ListTile(
                    title: Text('${widget.name.toString()} Engineering'.toUpperCase(),
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 20.0
                    ),),
                    subtitle: Text('year ${widget.year_convert[widget.year-1]}'),
                  ),
                  expandedHeight: 160.0,
                  pinned: true,
                  floating: true,
                  bottom: TabBar(
                    controller: _controller,
                    onTap: (_) {
                      print('tapped ${_} page');
                    },
                    tabs: [
                      Tab(
                        child: Text('First Semester'),
                      ),
                      Tab(
                        child: Text('Second Semester'),
                      )
                    ],
                  ),
                )
              ];
            },
            body: TabBarView(
              controller: _controller,
              children: [
                ListView.builder(
                    itemCount: widget.list_of_courses[0].length,
                    itemBuilder: (BuildContext context, int index) {
                      return Card(
                        child: Container(
                          child: ListTile(
                            onTap: () {

                              Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context)=>
                                      ChosenCourse('${widget.list_of_courses[0][index].toString()}'))
                              );

                              print(
                                  'course ${courses_materials[widget.list_of_courses[0][index]]['about']['name']} was pressed');
                            },
                            title: Text(widget.list_of_courses[0][index]),
                            subtitle: Text(courses_materials[widget
                                .list_of_courses[0][index]]['about']['name']),
                            trailing: Icon(Icons.download_outlined),
                          ),
                        ),
                      );
                    }),
                ListView.builder(
                    itemCount: widget.list_of_courses[1].length,
                    itemBuilder: (BuildContext context, int index) {
                      return Card(
                        child: Container(
                          child: ListTile(
                            onTap: () {
                              
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context)=>
                                ChosenCourse(widget.list_of_courses[1][index].toString()
                                )
                                )
                              );
                              
                              print(
                                  'course ${courses_materials[widget.list_of_courses[1][index]]['about']['name']} was pressed');
                            },
                            title: Text(widget.list_of_courses[1][index]),
                            subtitle: Text(courses_materials[widget
                                .list_of_courses[1][index]]['about']['name']),
                            trailing: Icon(Icons.download_outlined),
                          ),
                        ),
                      );
                    }),
              ],
            )),
      ),
    );
  }
}

//bringing scaffold it from the main to this side

// class scafoldIt extends StatelessWidget {
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         body: Courses(programYearCourses['computer']['1']),
//       ),
//     );
//   }
// }
