import "package:flutter/material.dart";
import 'logo.dart';
import "main.dart";
import "backgroundoverlay.dart";

class CodeConfirmationState extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return CodeConfirmation();
  }
}

class CodeConfirmation extends State<CodeConfirmationState> {
  TextEditingController codeConfirmation = TextEditingController();
  Widget codeConfirmationIcon = Icon(Icons.coronavirus);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Confirm code"),
          centerTitle: true,
         // backgroundColor: appBarColor,
        ),
        body: Stack(
          children: [
            //BackgroundOverlayState("./assets/images/confirmCodeLibrary.jpg"),
            ListView(children: [
              LogoImage("./assets/images/code.png"),
              Container(
                margin: EdgeInsets.fromLTRB(0, 10, 10, 0),
                child: Center(child: Text("Enter your email below")),
              ),
              Container(
                alignment: Alignment.center,
                padding: EdgeInsets.all(15),
                child: TextFormField(
                  autofocus: true,
                  controller: codeConfirmation,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderSide: BorderSide(

                      ),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    prefixIcon: codeConfirmationIcon,
                    labelText: "Confirm code",
                    hintText: "Enter the confirmation code",

                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  RaisedButton(
                      child: Text("Submit"),
                      onPressed: () {
                        Navigator.pushNamed(
                            context, "/forgotPassword/email/codeConfirmation/passwordReset");
                      },
                      ),
                  Container(
                    margin: EdgeInsets.fromLTRB(50, 0, 0, 0),
                    child: ElevatedButton(
                      onPressed: (){
                        //todo
                      },
                        child: Text("Resend code")),
                  )
                ],
              )
            ]),
          ],
        ));
  }
}
