import 'package:flutter/material.dart';
import "logo.dart";

class PasswordResetState extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PasswordReset();
  }
}

class PasswordReset extends State<PasswordResetState> {

  bool _obscurity = true;

  Widget passwordSufixIcon() {
    if (_obscurity == true) {
      return Icon(Icons.visibility_off);
    } else {
      return Icon(Icons.visibility);
    }
  }

  void _togglePasswordView() {
    setState(() {
      _obscurity = !_obscurity;
    });
  }

  TextEditingController _newPassword = TextEditingController();
  TextEditingController _confirmNewPassword = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Password reset"),
        centerTitle: true,
       // backgroundColor: appBarColor,
      ),
      body: ListView(
        children: [
          LogoImage("./assets/images/forgotpassword.png"),
          Center(
            child: Container(
              margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: Center(child: Text("Reset password below")),
            ),
          ),
          // PasswordFieldState(_newPassword, "New password",
          //     "Enter your new password", passwordIcon),
          // PasswordFieldState(_confirmNewPassword, "Confirm new password",
          //     "Confirm your new password", passwordIcon),
          Container(
              padding:EdgeInsets.all(15),
              child:TextFormField(
              validator: (value) => value!.length < 8
                  ? "Password should be more than 8 characters"
                  : null,
              autofocus: true,
              controller: _newPassword,
              obscureText: _obscurity,
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.lock),
                suffix: InkWell(
                    onTap: _togglePasswordView,
                    child: passwordSufixIcon()),
                border: OutlineInputBorder(
                  borderSide: BorderSide
                    (
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                labelText: "Enter new password",
                hintText: "Enter your new password",
              ))
          )

          ,
          Container(
              padding:EdgeInsets.all(15),
              child:TextFormField(
              validator: (value) => value==_newPassword
                  ? "Passwords do not match"
                  : null,
              controller: _confirmNewPassword,
              obscureText: _obscurity,
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.lock),
                suffix: InkWell(
                    onTap: _togglePasswordView,
                    child: passwordSufixIcon()),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                labelText: "Confirm new password",
                hintText: "Confirm enter your new password",
              ))
          )

          ,

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                  child: Text("Confirm"),
                  onPressed: () {
                    Navigator.pushNamed(context, "/");
                  },
                 
                  ),
            ],
          )
        ],
      ),
    );
  }
}
