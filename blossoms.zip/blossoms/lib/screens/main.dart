import 'package:blossoms/screens/chooseProgram.dart';
import "package:flutter/material.dart";
import 'login.dart';
import "signUp.dart";
import "forgotPassword.dart";
import "codeConfirmation.dart";
import 'chosenCourse.dart';
import 'availablePrograms.dart';

const appBarColor = Colors.blue;

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.indigo,
      ),
      initialRoute: "/",
      routes: {
        "/": (context) => LoginPageState(),
        "/signup": (context) => SignupPageState(),
        "/forgotPassword": (context) => ForgotPasswordState(),
        "/forgotPassword/codeConfirmation": (context) =>
            CodeConfirmationState(),
        "/login/landingPage": (context) =>
            chooseProgram(),
      },
      title: "Blossoms",
    ));
