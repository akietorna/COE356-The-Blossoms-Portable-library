import 'package:flutter/material.dart';
import 'availablePrograms.dart';
import 'courses.dart';

class yearSelection extends StatefulWidget {
  late String name_of_program;
  yearSelection(this.name_of_program);

  @override
  _yearSelectionState createState() => _yearSelectionState(name_of_program);
}

class _yearSelectionState extends State<yearSelection> {

  late String name;
  //String name_of_program = 'computer';
  _yearSelectionState(this.name);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: OrientationBuilder(
            builder: (context, orientation)=>
            orientation==Orientation.portrait?portrait_grid(this.name):landscape_listTiles(this.name),
          ),
        )
    );
  }
}

class portrait_grid extends StatelessWidget {
  late String name_of_program;

  portrait_grid(this.name_of_program);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [

        SizedBox(
            height: MediaQuery.of(context).size.height*0.15
        ),
        Expanded(
            child: GridView.builder(
                itemCount: programYearCourses['${this.name_of_program}']['years'],
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 5.0,
                    mainAxisSpacing: 10.0
                ),
                itemBuilder: (BuildContext context, int index){
                  return Card(
                    shadowColor: Color.fromRGBO(255, 100, 255, 1.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color: Color.fromRGBO(200, 100, 255, 0.25)
                      ),
                      child: ListTile(
                        onTap: (){

                          Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context)=>
                                  Courses(this.name_of_program, index+1)
                              )
                          );

                          print('portrait year ${index + 1} pressed');
                        },
                        title: Text('Year ${index + 1}'),
                      ),
                    ),
                  );
                })
        )
      ],
    );
  }
}

class landscape_listTiles extends StatelessWidget {
  //String name_of_program = 'computer';
  late String name_of_program;

  landscape_listTiles(this.name_of_program);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
              itemCount: programYearCourses['${this.name_of_program}']['years'],
              itemBuilder: (BuildContext context, int index){
                return Card(
                  margin: EdgeInsets.all(12.0),
                  shadowColor: Color.fromRGBO(255, 100, 255, 1.0),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Color.fromRGBO(200, 100, 255, 0.25)
                    ),
                    child: ListTile(
                      onTap: (){
                        
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context)=>
                          Courses(this.name_of_program, index+1)
                          )
                        );
                        
                        print('landScape year ${index +1} pressed');
                      },
                      title: Text('Year ${index + 1}'),
                    ),
                  ),
                );
              }),
        )
      ],
    );
  }
}





